class Hero < ApplicationRecord
end
