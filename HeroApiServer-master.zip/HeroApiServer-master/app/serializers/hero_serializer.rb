class HeroSerializer < ActiveModel::Serializer
  attributes :id, :name
end