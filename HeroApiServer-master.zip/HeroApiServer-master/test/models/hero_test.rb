require 'test_helper'

class HeroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
